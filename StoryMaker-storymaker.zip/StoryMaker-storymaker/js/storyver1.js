//copyright Graham Hammond 2023
function makestory(){
var person=prompt("Enter a Name");
var thing=prompt("Enter a Thing");
var colour=prompt("Enter a Colour");
var animal=prompt("Enter a Animal");
var time=prompt("Enter a Time");
var mf=prompt("Enter he or she");
var activity=prompt("Enter an Activity");
var ranthing=prompt("Enter a Random Thing");
document.write("There was a person named "+person+". "+mf+" loved to play "+activity+". "+mf+" also loved "+animal+"s a lot. One time at "+time+" "+mf+" saw a "+colour+" "+animal+" jumping at the ground."+mf+" was very happy to see the "+colour+" "+animal+". "+mf+" liked the "+animal+" a lot and "+mf+" brought the "+animal+" home. "+mf+" brought it home and had a lot of fun with the "+animal+". "+mf+" had so much fun and "+ranthing+" a lot. ");
}
