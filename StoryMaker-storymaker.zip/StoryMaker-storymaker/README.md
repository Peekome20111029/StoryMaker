# StoryMaker Ver 1
This makes a story from prompt in js and html. <br>
storyver1.html html for the story maker <br>
storyver1.js JavaScript for the story maker <br>
